let myBook ={
    title:'MaanavaN Angular Book',
    author:'Sathihs',
    pageCount:325
}

let getSummary = function(book){

    return {
        summary:`${book.title} by ${book.author}`,
        pageCountsummary:`${book.title} is ${book.pageCount} pages`
    }

}

let bookSummary = getSummary(myBook)
console.log(bookSummary.pageCountsummary)
console.log(bookSummary.summary)
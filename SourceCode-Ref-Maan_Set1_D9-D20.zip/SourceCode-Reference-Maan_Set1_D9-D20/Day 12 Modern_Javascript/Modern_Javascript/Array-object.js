let myhotebookinglist = [
{
name:'Park Inn Hospitality',
type:'Serviced apartment'
},

{name:'Fairfield by Marriott',
type:'hote'
},
];

console.log(myhotebookinglist)

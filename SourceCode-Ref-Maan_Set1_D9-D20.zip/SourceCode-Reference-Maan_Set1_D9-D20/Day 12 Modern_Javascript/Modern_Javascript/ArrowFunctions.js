//ES6 / ES2015 

var myFunc = () => {
    console.log("I am Arrow Functions")
}

var myFunc = (a,b,c) =>{
    return a * b * c;
}

var myFunc = a =>{
    return a * a 
}

var myFunc = a => a * a

myFunc();
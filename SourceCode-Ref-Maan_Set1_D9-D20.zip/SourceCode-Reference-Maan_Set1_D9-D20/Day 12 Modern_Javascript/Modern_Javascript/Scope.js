//Difference b/w var let const
// ES2016 spec defines 
// var 

//Scope

/* //Function Scope vs Block Scope
var myname = 'Learn Code'; // Global
function myFun(){
    console.log("Inside Function"+myname); 
    var myname = 'MaanavaN'; //local
   // console.log(myname);
}

console.log(myname); 

myFun() */

if(true){
    var mycourse1 = 'Angular';
    let mycourse2 = 'ReactJS';
    const mycourse3 = 'NodeJS';
    console.log(mycourse1)
    console.log(mycourse2)
    console.log(mycourse3)
    //mycourse3 = 'VueJS'
  /*   let mycourse2 = 'MEAN'
    console.log(mycourse2) */
    var mycourse1 = 'MERN';
    console.log(mycourse1)
}
var mycourse1 = 'MEAN';
console.log(mycourse1)
let mycourse2 = 'Express'

console.log(mycourse2)
//console.log(mycourse3)
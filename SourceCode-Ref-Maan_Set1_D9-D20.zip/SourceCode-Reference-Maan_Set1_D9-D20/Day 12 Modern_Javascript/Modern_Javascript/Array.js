/* let mycourse = ["Angular","ReactJS",1,{name:"Sathihs"},function(){

}]

// for of loop

for (let mydata of mycourse){
    console.log(mydata)
}

for (let mydata in mycourse){
    console.log(mycourse[mydata])
}

*/

const letters = ['a','b','c'];

letters.forEach((letter,index,arr) =>{
console.log(letter,index,arr)
}
)
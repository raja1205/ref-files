//Form -- Username,Passeord ---> Servide


let user = {
    UserName : 'MaanavaN',
    age : 23,
    location : 'Chennai',
    address: []
    
}

for(let mydata in user ){
    console.log(user[mydata])
}

//React JS - Form ----> Servide ----> Database
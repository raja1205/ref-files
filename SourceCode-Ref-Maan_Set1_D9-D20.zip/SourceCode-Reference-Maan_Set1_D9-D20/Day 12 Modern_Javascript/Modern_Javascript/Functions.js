/* function add(){

} */

let add = function(a,b,c) {
    return a+b+c;
}

let result = add(10,1,5)
console.log(result)

let getScoreTest = function(name,score=0){
    console.log("Name:"+ name 
    + score)
    console.log(`Name: ${name} 
    Score: ${score}`)

    return `Name: ${name} Score: ${score}`

}

let scoreTest = getScoreTest("MaanavaN")
console.log(scoreTest)
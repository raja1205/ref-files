import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
//import Tick from './Tick';
import Hooktimer from './Hooktimer';
import * as serviceWorker from './serviceWorker';

ReactDOM.render(
  <React.StrictMode>
    <Hooktimer />
  </React.StrictMode>,
  document.getElementById('root')
);

/* function mytick(){
  ReactDOM.render(
    <React.StrictMode>
      <Tick />
    </React.StrictMode>,
    document.getElementById('root')
  );
} */


//setInterval(mytick, 1000);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();

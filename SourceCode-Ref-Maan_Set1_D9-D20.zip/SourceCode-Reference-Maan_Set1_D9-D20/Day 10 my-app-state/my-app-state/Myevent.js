import React,{Component} from 'react';

export default class Myevent extends Component {

    handleClick() {
        console.log("MaanavaN Learn Code")
    }


    render() {
      return (
      <div>
     <button onClick={this.handleClick}>Activate Lasers</button>
      </div>
      
      )
    }
  }
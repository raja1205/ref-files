import React,{Component} from 'react';

import './App.css';

class App extends Component {

  constructor(){
    super()
   // console.log("MaanavaN Learn Code",this)
    this.state = {      //Initial State
      displayinfo:false
    }
    console.log("Component this",this)
  //  this.readMore = this.readMore.bind(this)
  //this.toggleDisplayinfo = this.toggleDisplayinfo.bind(this)
    
  }

  /* readMore(){
    console.log("read info",this)
    // eslint-disable-next-line react/no-direct-mutation-state
     // this.state.displayinfo = true;
     this.setState({displayinfo: true}); // Predefined Method

  } */

/*   showLess(){
    this.setState({displayinfo: false});
  } */

   /*   showLess = () => {
      this.setState({displayinfo: false});
     } */

     toggleDisplayinfo(){
       this.setState({displayinfo: !this.state.displayinfo});
     }


  render(){

    /* let info = this.state.displayinfo ? (
      <div>
        <p>Technologies Training in Tamil</p>
      <p>ReactJS Training in Tamil</p>
      </div>
    
    ):null; */

    /* if(!this.state.displayinfo){
      info=null;
    }  */

    return (
      <div className="App">
        <header className="App-header">
         <h1>MaanavaN Learn Code</h1>
         <p>Full Stack Development(MEAN,MERN,Spring)</p>
         <p>ReactJS,Angular,Vue JS, ExtJS</p>
         { 
         this.state.displayinfo ? (
          <div>
           <p>Technologies Training in Tamil</p>
            <p>ReactJS Training in Tamil</p>
            {
            /*  <button onClick={() => this.showLess()}>Show Less</button> */
            <button onClick={() => this.toggleDisplayinfo()}>Show Less</button>
            }
           </div>
          ):(
            <button onClick={() => this.toggleDisplayinfo()}>Read More</button>
          )
      }
      </header>
      </div>
    );
  }

}

export default App;

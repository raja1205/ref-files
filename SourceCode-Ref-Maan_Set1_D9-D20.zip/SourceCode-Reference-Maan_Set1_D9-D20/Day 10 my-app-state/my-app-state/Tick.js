import React from 'react';
import Clock from './Clock';
import Myclock from './Myclock';
import './App.css';
function Tick() {
    return  (
      <div className="App">
        <header className="App-header">
        <h1>Parent Component</h1>
        <Clock date={new Date()} />
        <Myclock></Myclock>
        {/* <h2>It is {new Date().toLocaleTimeString()}.</h2> */}
        </header>
      </div>
    );
}

export default Tick;
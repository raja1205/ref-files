import React, { useState} from 'react';

function Hooktimer(){

    function now(){
        return new Date().toLocaleTimeString();
    }
    
    function updateTime(){
        setTime(now());
    }
    
    setInterval(updateTime,1000);
 
    var [time,setTime]=useState(now())

   return (
       <div>
           <h1>{time}</h1>
       </div>
   )
}

export default Hooktimer;
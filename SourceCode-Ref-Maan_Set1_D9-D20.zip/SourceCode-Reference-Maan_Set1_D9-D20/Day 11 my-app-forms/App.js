import React, { useState } from 'react';
import './Form.css';

function App() {

  const [name,setName] = useState("");
  const [headingText,setHeading] = useState();

  function handleChange(event){
    //console.log("Data Changed")
   // console.log(event.target.value);
    setName(event.target.value)
   /*  console.log(event.target.type);
    console.log(event.target.placeholder); */
  }

  function handleClick(event) {
    //console.log("Submit")
    setHeading(name)
    event.preventDefault();
  }

  return (
    <div className="container">
      <h1>Hello {name} </h1>
      <h1>After Submit{headingText} </h1>
      <form onSubmit={handleClick}>
      <input 
      onChange={handleChange}
      type="text" placeholder="Enter your Name"
      value={name}
      />
      <button type="submit">Submit</button>
      </form>
     
    </div>
    
  );
}

export default App;

import React from 'react';

function UserGreeting(props) 
{

    const currentTime = new Date(2020,7,24,18).getHours();

    return (
      currentTime > 12 ? <h1>Still Are you Working</h1>:null;
    )
}

export default UserGreeting;


/* Javascript && 
----------------------------------------------------------------
var x =1

(x > 3 && x < 7)

(Expression && Expression)

React JS

CONDITION && Expression

true :  */
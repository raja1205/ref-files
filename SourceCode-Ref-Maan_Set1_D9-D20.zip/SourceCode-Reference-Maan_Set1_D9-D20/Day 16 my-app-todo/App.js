import React from 'react';
import './App.css';
import ShoppingList  from './ShoppingLocalStorage'
function App() {
  return (
    <div className="App">
      <header className="App-header">
        <ShoppingList></ShoppingList>
      </header>
    </div>
  );
}

export default App;

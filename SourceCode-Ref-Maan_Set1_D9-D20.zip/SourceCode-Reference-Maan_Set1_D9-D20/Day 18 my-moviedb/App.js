import React from 'react';
import Movie from './Movie1'
import './App.css';

function App() {
  return (
    <div className="container">
  <Movie></Movie>
</div>
    
  );
}

export default App;

// Rest parameter - javascript ecma6
//Spread operator
// ...


/* function sum(a, b) {
    return a + b;
} */

/* function sum(...args)
{
    let result = 0;

    for (let arg of args) result += arg;

    return result;
 
   /*  for(let arg of args){
        console.log(arg);
    }
 */
//}
//yresult = sum(100,2,3,5,6,7,8)
//console.log(myresult) */

function mydata(x,y,...z){

    console.log(x)
    console.log(y)
    console.log(z)
    console.log(z.length)
}

//mydata('John','Peter','James','Pammy')

const mydat1 = ['John','Peter','James','Pammy'];

const newarray = [...mydat1,"MaanavaN","Sathish"]

//console.log(newarray)

const newarray2 = [...newarray]

console.log(newarray2)
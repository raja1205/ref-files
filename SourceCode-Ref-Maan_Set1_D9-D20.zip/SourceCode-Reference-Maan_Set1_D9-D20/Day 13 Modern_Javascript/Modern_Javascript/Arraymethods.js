/* var numbers = [1,7,8,9,3,5,8,9,0]

var mydata = numbers.filter(function(number){

    return number > 6

});

console.log(mydata) */

/* var dataCollection = [
    {
        id:1,
        title:'Angular Training'
    },
    {
        id:2,
        title:'React JS Training'
    },
    {
        id:3,
        title:'Node JS Training'
    },
    {
        id:1,
        title:'Vue JS Training'
    }


]

var mydata = dataCollection.find(function(myid){
        return myid.id === 1;
});

console.log(mydata) */
/* 
const names = ['John','Peter','James','Pammy']

let myName = names.filter(name => name.includes('am'));

console.log(myName) */


/* const places = ['Africa','Asia','Europe','Australia'];

const myindex = places.filter(function(place,index){
    return index > 1;
})

console.log(myindex) */

// map

/* let numbers =[2,4,6,8]

let mydata = numbers.map(number => number * 2)

console.log(mydata) */

const students = [
    {name:'John', score:'33'},
    {name:'Jane', score:'35'},
    {name:'Tom', score:'45'}
]

//console.log(students[0].score)

let myscore = students.map(function(student){
    return student.score
}) 

console.log(myscore)
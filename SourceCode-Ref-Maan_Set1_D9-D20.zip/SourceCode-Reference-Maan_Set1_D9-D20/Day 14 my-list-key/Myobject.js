const person ={
    name: 'John',
    age: 30,
    location:'New York'
};

let mydata = Object.keys(person)
console.log(mydata)


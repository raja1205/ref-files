import React from 'react';
import './App.css';

function App() {

  const dataCollection = [{
    id:1,
    title:'ReactJS Tamil Training',
    label:'MaanavaN Learn Code'
  }];
/* 
  let ListTemplate;

  if(dataCollection.length){
    ListTemplate = dataCollection.map((item,index) =>
  <li key={index}>{item.title}- {item.label}</li>
    );
  }
  else{
          ListTemplate = <li>No Messages Found</li>
  } */

  return (
    <div className="App">
      <header className="App-header">
        <div>
                <ul>{
                  dataCollection.length ? (
                  dataCollection.map((item, index) => <li key={index}>{item.title}</li>)
                  )
                  : <li>No Messages Found</li>
                  }</ul>
        </div>
      
      </header>
    </div>
  );
}

export default App;
